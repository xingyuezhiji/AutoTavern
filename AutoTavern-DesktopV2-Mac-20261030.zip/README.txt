AutoTavern Desktop V2 (mac)
Run desktop_tavern/setup-mac.command first.
Read docs/DESKTOP_V2.md. Default mode is recommendations.
The bundled geometry/log are synthetic offline samples only.
No real game-client acceptance has been completed.
