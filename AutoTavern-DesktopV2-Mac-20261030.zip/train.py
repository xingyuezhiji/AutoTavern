#!/usr/bin/env python3
"""Train a small TavernArena-compatible policy on OpenI CloudBrains.

This script is designed for environments where the job can clone this repository
but cannot clone GitHub directly. It can:

1. verify/apply the public observe2 patch;
2. install TavernGym and PyTorch dependencies;
3. train behavior cloning and optional PPO from complete-game outcome rewards;
4. export a checkpoint that can be loaded locally by `tavern_policy.py`.

No arena key, live match state, model registry credential, or game save is read
or written by this script.
"""

from __future__ import annotations

import argparse
import faulthandler
import hashlib
import json
import os
import platform
import random
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from importlib.metadata import version
from importlib.util import find_spec
from pathlib import Path
from typing import Iterable

from action_limits import limit_action_mask


REPO_ROOT = Path(__file__).resolve().parent
# Match the allocator configuration used by the successful CoreX reference.
# This must be set before importing Torch in the parent or CUDA probe.
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "max_split_size_mb:128")
if os.getenv("TAVERN_ACCELERATOR") == "metax":
    for variable in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                     "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        os.environ[variable] = "1"
PATCH_URL = "https://rizling.top/downloads/autotavern-observe2.patch"
PATCH_SHA256 = "1e48a071cad63c284debbf917cb012595a405a4ef5ab66180eb2918e205aaac0"
PINNED_COMMIT = "fb61201a557ddd36a411cf44aac51ce4d9b606ce"
ARENA_RULESET_ID = "tg36-bc45cfc55a0e5cd6c14c"
ARENA_CATALOG_SHA256 = "c4c42e6ce5060e1b79fbcd5f4edbf6d17495f0f52690072481d690610f7ef6d7"
FEATURE_DIM = 4017
CARD_DIM = 447
ACTION_DIM = 245


def run(cmd: list[str], *, cwd: Path = REPO_ROOT, check: bool = True) -> subprocess.CompletedProcess:
    print("+ " + " ".join(cmd), flush=True)
    return subprocess.run(cmd, cwd=str(cwd), check=check)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def ensure_observe2_patch() -> None:
    """Apply the arena public patch if this checkout is still the base release."""
    patched_marker = REPO_ROOT / "crates" / "taverngym" / "src" / "obs2.rs"
    if patched_marker.exists():
        print("observe2 patch already present", flush=True)
        return

    current = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=str(REPO_ROOT),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        check=False,
    ).stdout.strip()
    if current and current != PINNED_COMMIT:
        print(f"warning: current git commit is {current}, expected base {PINNED_COMMIT}", flush=True)

    patch_path = Path("/tmp/autotavern-observe2.patch")
    print(f"downloading observe2 patch: {PATCH_URL}", flush=True)
    urllib.request.urlretrieve(PATCH_URL, patch_path)
    got = sha256_file(patch_path)
    if got != PATCH_SHA256:
        raise RuntimeError(f"patch sha256 mismatch: got {got}, expected {PATCH_SHA256}")

    run(["git", "apply", str(patch_path)])
    print("observe2 patch applied", flush=True)


def install_environment() -> None:
    """Install dependencies inside the OpenI job container."""
    ensure_observe2_patch()
    wheel_manifest = REPO_ROOT / "openi_taverngym_wheel.json"
    model_root = os.getenv("TAVERN_PRETRAIN_MODEL_DIR")
    if (wheel_manifest.exists() and model_root and platform.system() == "Linux"
            and platform.machine() == "x86_64"):
        manifest = json.loads(wheel_manifest.read_text())
        bundled = REPO_ROOT / "prebuilt" / manifest["filename"]
        matches = [bundled] if bundled.is_file() else list(Path(model_root).rglob(manifest["filename"]))
        if len(matches) != 1 or sha256_file(matches[0]) != manifest["sha256"]:
            raise RuntimeError("Attached simulator wheel missing or checksum mismatch")
        if find_spec("torch") is None or find_spec("numpy") is None:
            raise RuntimeError("Vendor image must already provide Torch and NumPy")
        run([sys.executable, "-m", "pip", "install", "--no-deps", str(matches[0])])
        import taverngym

        fingerprint = taverngym.build_info()["source_hash"]
        if fingerprint != manifest["source_hash"] or fingerprint != taverngym.source_hash(REPO_ROOT):
            raise RuntimeError("Prebuilt simulator source fingerprint mismatch")
        print(f"Prebuilt simulator verified source_hash={fingerprint}; "
              "vendor Torch/NumPy preserved", flush=True)
        return
    # Avoid maturin's implicit Rust bootstrap over a slow overseas connection.
    os.environ.setdefault("RUSTUP_DIST_SERVER", "https://rsproxy.cn")
    os.environ.setdefault("RUSTUP_UPDATE_ROOT", "https://rsproxy.cn/rustup")
    os.environ.setdefault("RUSTUP_TOOLCHAIN", "1.98.1")
    cargo_home = Path(os.environ.get("CARGO_HOME", Path.home() / ".cargo"))
    os.environ["PATH"] = str(cargo_home / "bin") + os.pathsep + os.environ["PATH"]
    if shutil.which("rustup") is None:
        # Minimal BI-V100 images have neither curl nor wget. Download the
        # standalone installer with Python rather than the shell bootstrap.
        architecture = {"x86_64": "x86_64", "aarch64": "aarch64"}.get(platform.machine())
        if platform.system() != "Linux" or architecture is None:
            raise RuntimeError("automatic Rust installation requires Linux x86_64/aarch64")
        # rustup selects installer/proxy mode from its executable filename.
        installer = Path("/tmp/rustup-init")
        url = f"https://rsproxy.cn/rustup/dist/{architecture}-unknown-linux-gnu/rustup-init"
        for attempt in range(1, 4):
            try:
                print(f"downloading Rust installer (attempt {attempt}): {url}", flush=True)
                with urllib.request.urlopen(url, timeout=120) as response, installer.open("wb") as target:
                    shutil.copyfileobj(response, target)
                break
            except (OSError, urllib.error.URLError):
                installer.unlink(missing_ok=True)
                if attempt == 3:
                    raise
        installer.chmod(0o755)
        run([str(installer), "-y", "--profile", "minimal", "--default-toolchain", "none"])
    run(["rustup", "toolchain", "install", os.environ["RUSTUP_TOOLCHAIN"],
         "--profile", "minimal"])
    cargo_home.mkdir(parents=True, exist_ok=True)
    config = cargo_home / "config.toml"
    if not config.exists():
        config.write_text(
            '[source.crates-io]\nreplace-with = "rsproxy-sparse"\n'
            '[source.rsproxy-sparse]\nregistry = "sparse+https://rsproxy.cn/index/"\n'
            '[net]\nretry = 3\n[http]\ntimeout = 120\n', encoding="utf-8")
    run(["rustc", "--version"])
    run([sys.executable, "-m", "pip", "install", "maturin>=1.15,<2"])
    # Preserve the image's NumPy 1.x: its CoreX TensorFlow requires <1.24
    # and CuPy requires <1.26. Torch 2.1 also needs the NumPy 1.x ABI.
    if os.getenv("TAVERN_ACCELERATOR") == "metax":
        # MACA PyTorch 2.8 images use Python 3.12, which cannot install NumPy
        # 1.23. Preserve their supported ABI and other bundled dependencies.
        if find_spec("numpy") is None:
            run([sys.executable, "-m", "pip", "install", "numpy>=1.26,<3"])
        else:
            print(f"keeping MACA numpy={version('numpy')}", flush=True)
    elif find_spec("numpy") is None or int(version("numpy").split(".")[0]) >= 2:
        run([sys.executable, "-m", "pip", "install", "numpy>=1.23,<1.24"])
    else:
        print(f"keeping existing numpy={version('numpy')}", flush=True)
    # ILUVATAR / BI-V100 images often carry a platform-adapted torch build.
    # Do not overwrite it unless torch is genuinely absent.
    if find_spec("torch") is None:
        run([sys.executable, "-m", "pip", "install", "torch"])
    else:
        import torch

        print(f"keeping existing torch={torch.__version__}", flush=True)
    run([sys.executable, "-m", "pip", "install", "--no-build-isolation", "."])


def import_runtime():
    import numpy as np
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    import taverngym

    return np, torch, nn, F, taverngym


@dataclass
class ModelConfig:
    feature_dim: int = FEATURE_DIM
    card_dim: int = CARD_DIM
    action_dim: int = ACTION_DIM
    card_vocab: int = 4096
    card_emb: int = 32
    hidden: int = 512
    dropout: float = 0.05
    action_identity: bool = False
    architecture: str = "mlp"
    transformer_dim: int = 384
    transformer_layers: int = 8
    transformer_heads: int = 8


def build_model_class(nn, torch):
    class TavernBCPolicy(nn.Module):
        def __init__(self, cfg: ModelConfig):
            super().__init__()
            self.cfg = cfg
            if cfg.architecture == "entity_transformer":
                from entity_policy import build_entity_policy
                self.entity = build_entity_policy(nn, torch, cfg)
                return
            if cfg.architecture != "mlp":
                raise ValueError("unsupported policy architecture")
            self.card_emb = nn.Embedding(cfg.card_vocab, cfg.card_emb, padding_idx=0)
            self.feature_net = nn.Sequential(
                nn.LayerNorm(cfg.feature_dim),
                nn.Linear(cfg.feature_dim, cfg.hidden),
                nn.GELU(),
                nn.Dropout(cfg.dropout),
                nn.Linear(cfg.hidden, cfg.hidden),
                nn.GELU(),
            )
            self.head = nn.Sequential(
                nn.Linear(cfg.hidden + cfg.card_emb, cfg.hidden),
                nn.GELU(),
                nn.Dropout(cfg.dropout),
                nn.Linear(cfg.hidden, cfg.action_dim),
            )
            if cfg.action_identity:
                from action_identity import build_identity_head
                self.identity_head = build_identity_head(nn, torch, cfg)

        def forward(self, features, cards):
            if self.cfg.architecture == "entity_transformer":
                return self.entity(features, cards)
            cards = cards.clamp(min=0, max=self.cfg.card_vocab - 1)
            emb = self.card_emb(cards)
            present = (cards != 0).float().unsqueeze(-1)
            pooled = (emb * present).sum(dim=1) / present.sum(dim=1).clamp_min(1.0)
            x = self.feature_net(features.float())
            logits = self.head(torch.cat([x, pooled], dim=-1))
            if self.cfg.action_identity:
                logits = logits + self.identity_head(x, emb, cards, pooled)
            return logits

    return TavernBCPolicy


def decode_obs(np, obs_bytes: tuple[bytes, bytes], mask_bytes: bytes):
    features = np.frombuffer(obs_bytes[0], dtype="<f4").copy()
    cards = np.frombuffer(obs_bytes[1], dtype="<i4").copy()
    mask = np.frombuffer(mask_bytes, dtype=np.uint8).astype(bool)
    if features.shape != (FEATURE_DIM,) or cards.shape != (CARD_DIM,) or mask.shape != (ACTION_DIM,):
        raise ValueError(f"bad obs shapes: {features.shape}, {cards.shape}, {mask.shape}")
    return features, cards, limit_action_mask(features, mask)


def generate_bot_dataset(np, taverngym, *, samples: int, seed: int, max_games: int,
                         teacher: str = "bot"):
    if teacher == "guide":
        from guide_teacher import generate_dataset
        return generate_dataset(np, taverngym, samples=samples, seed=seed,
                                max_games=max_games)
    features, cards, masks, actions = [], [], [], []
    game_ids = []
    game_count = 0
    started = time.time()
    print(f"generating bot dataset: samples={samples} seed={seed}", flush=True)
    while len(actions) < samples and game_count < max_games:
        game = taverngym.Game(seed + game_count)
        guard = 0
        while not game.is_over() and len(actions) < samples:
            progressed = False
            for seat in range(game.num_players):
                if not game.needs_action(seat):
                    continue
                action = int(game.bot_action(seat))
                obs = game.observe2(seat)
                mask_bytes = game.legal_mask(seat)
                f, c, m = decode_obs(np, obs, mask_bytes)
                if not m[action]:
                    raise RuntimeError(f"bot produced illegal action {action}")
                features.append(f)
                cards.append(c)
                masks.append(m)
                actions.append(action)
                game_ids.append(game_count)
                if len(actions) % 500 == 0:
                    print(f"dataset samples={len(actions)}/{samples} game={game_count} "
                          f"turn={game.turn} elapsed={time.time() - started:.1f}s", flush=True)
                game.step(seat, action)
                progressed = True
                if len(actions) >= samples:
                    break
            guard += 1
            if not progressed or guard > 50000:
                raise RuntimeError("game did not progress while generating data")
        game_count += 1
        if game_count % 10 == 0:
            elapsed = time.time() - started
            print(f"generated {len(actions)}/{samples} samples from {game_count} games in {elapsed:.1f}s", flush=True)

    if len(actions) < samples:
        raise RuntimeError(f"only generated {len(actions)} samples; increase --max-games")

    return (
        np.stack(features).astype("float32"),
        np.stack(cards).astype("int64"),
        np.stack(masks).astype(bool),
        np.asarray(actions, dtype="int64"),
        np.asarray(game_ids, dtype="int64"),
    )


def iter_minibatches(np, n: int, batch_size: int, *, shuffle: bool = True) -> Iterable:
    order = np.arange(n)
    if shuffle:
        np.random.shuffle(order)
    for start in range(0, n, batch_size):
        yield order[start : start + batch_size]


def cuda_training_ready(timeout: float = 180) -> bool:
    """Exercise the actual policy in a killable process before touching GPU here."""
    probe = """
import faulthandler
import os
import torch
from train import ModelConfig, build_model_class, move_policy, move_tensor
faulthandler.enable()
faulthandler.dump_traceback_later(20, repeat=True)
torch.set_num_threads(1 if os.getenv("TAVERN_ACCELERATOR") == "metax" else 4)
torch.set_num_interop_threads(1)
print("CUDA probe: checking device", flush=True)
if not torch.cuda.is_available():
    raise RuntimeError("CUDA is unavailable")
torch.cuda.set_device(0)
print(f"CUDA probe: gpu={torch.cuda.get_device_name(0)}", flush=True)
print("CUDA probe: initializing allocator", flush=True)
torch.empty(1, device="cuda")
torch.cuda.synchronize()
print("CUDA probe: allocator ready", flush=True)
print("CUDA probe: copying policy", flush=True)
cfg = ModelConfig()
model = move_policy(torch, build_model_class(torch.nn, torch)(cfg), "cuda")
print("CUDA probe: forward/backward/optimizer", flush=True)
opt = torch.optim.AdamW(model.parameters())
features = move_tensor(torch, torch.zeros(2, cfg.feature_dim), "cuda")
cards = move_tensor(torch, torch.zeros(2, cfg.card_dim, dtype=torch.long), "cuda")
mask = move_tensor(torch, torch.ones(2, cfg.action_dim, dtype=torch.bool), "cuda")
target = move_tensor(torch, torch.zeros(2, dtype=torch.long), "cuda")
loss = torch.nn.functional.cross_entropy(model(features, cards).masked_fill(~mask, -1e9), target)
loss.backward()
torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
opt.step()
torch.cuda.synchronize()
assert torch.isfinite(loss).item()
print("CUDA probe passed", flush=True)
"""
    print(f"checking CUDA training in isolated process (timeout={timeout}s)", flush=True)
    try:
        result = subprocess.run(
            [sys.executable, "-u", "-c", probe], cwd=str(REPO_ROOT), timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired:
        print("CUDA training probe timed out", flush=True)
        return False
    if result.returncode != 0:
        print(f"CUDA training probe failed (exit={result.returncode})", flush=True)
        return False
    return True


def move_tensor(torch, tensor, device, *, chunk_bytes: int = 8 * 1024 * 1024):
    """Use the staged dense transfer verified by OpenI task 898380 on CoreX."""
    target = torch.device(device)
    corex = (os.getenv("TAVERN_ACCELERATOR") == "iluvatar" or
             "corex" in str(Path(torch.__file__).resolve()).lower())
    if not (corex and tensor.device.type == "cpu" and target.type == "cuda"):
        return tensor.to(target)
    if tensor.layout != torch.strided or tensor.is_quantized:
        raise TypeError("CoreX staged transfer requires dense, non-quantized tensors")
    if chunk_bytes <= 0:
        raise ValueError("chunk_bytes must be positive")
    source = tensor.reshape(-1)
    destination = torch.empty(source.numel(), dtype=tensor.dtype, device=target)
    elements = max(1, chunk_bytes // tensor.element_size())
    for offset in range(0, source.numel(), elements):
        length = min(elements, source.numel() - offset)
        # Clone even contiguous inputs to avoid CPU storage-backed Tensor.to.
        staging = source.narrow(0, offset, length).clone()
        destination.narrow(0, offset, length).copy_(staging, non_blocking=False)
    return destination.view(tensor.shape)


def move_policy(torch, model, device):
    corex = (os.getenv("TAVERN_ACCELERATOR") == "iluvatar" or
             "corex" in str(Path(torch.__file__).resolve()).lower())
    staged = corex and torch.device(device).type == "cuda"
    print(f"model transfer={'staged_copy' if staged else 'native'} device={device}", flush=True)
    # _apply preserves Parameters, gradients, buffers and child modules.
    return model._apply(lambda tensor: move_tensor(torch, tensor, device))


def load_rollout_dataset(np, path: Path):
    """Load self-play rollouts (npz produced by tavern-arena/selfplay.py).

    Returns (features float16, cards int16, action_mask uint8, action int16, game_ids int32).
    Samples are keyed by the rollout `seed`, so validation splits whole games.
    """
    data = np.load(path)
    required = ("features", "cards", "action_mask", "action", "seed")
    missing = [k for k in required if k not in data.files]
    if missing:
        raise ValueError(f"{path} missing arrays: {missing}")
    features = data["features"]
    cards = data["cards"]
    mask = data["action_mask"]
    action = data["action"]
    game_ids = data["seed"]
    if features.shape[1] != FEATURE_DIM or cards.shape[1] != CARD_DIM:
        raise ValueError(f"unexpected rollout dims: {features.shape}, {cards.shape}")
    if mask.shape[1] != ACTION_DIM:
        raise ValueError(f"unexpected action mask width: {mask.shape}")
    print(f"rollout dataset {path}: samples={len(action)} games={len(np.unique(game_ids))}",
          flush=True)
    return features, cards, mask, action, game_ids


def train_bc(args) -> None:
    # Keep the parent CUDA context untouched until the child has exited.
    # Vendor runtimes may block allocation in another process after detection
    # initializes a context in the parent.
    use_cuda = not args.cpu and cuda_training_ready()
    if not args.cpu and not use_cuda:
        raise RuntimeError("CUDA training probe failed; CPU fallback is disabled")
    np, torch, nn, F, taverngym = import_runtime()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.set_num_threads(1 if os.getenv("TAVERN_ACCELERATOR") == "metax" else min(4, os.cpu_count() or 1))
    torch.set_num_interop_threads(1)
    if os.getenv("TAVERN_ACCELERATOR") == "metax":
        faulthandler.cancel_dump_traceback_later()
    print(json.dumps({"runtime_threads": torch.get_num_threads(),
                      "interop_threads": torch.get_num_interop_threads(),
                      "periodic_tracebacks": os.getenv("TAVERN_ACCELERATOR") != "metax",
                      "torch_version": torch.__version__}), flush=True)

    device = torch.device("cuda" if use_cuda else "cpu")
    print(f"device={device}", flush=True)
    if device.type == "cuda":
        print(f"gpu={torch.cuda.get_device_name(0)}", flush=True)
    print(f"taverngym build={taverngym.build_info()}", flush=True)
    if os.getenv("TAVERN_ACCELERATOR") in {"iluvatar", "metax"}:
        # CoreX supports the math attention path; avoid NVIDIA-only fused paths.
        if hasattr(torch.backends.cuda, "enable_flash_sdp"):
            torch.backends.cuda.enable_flash_sdp(False)
            torch.backends.cuda.enable_mem_efficient_sdp(False)
            torch.backends.cuda.enable_math_sdp(True)
        if hasattr(torch.backends, "mha") and hasattr(torch.backends.mha, "set_fastpath_enabled"):
            torch.backends.mha.set_fastpath_enabled(False)
        runtime_name = "CoreX" if os.getenv("TAVERN_ACCELERATOR") == "iluvatar" else "MACA"
        print(f"{runtime_name} math attention enabled; device updates remain on GPU", flush=True)
    if args.capacity_ablation:
        from capacity_ablation import gpu_preflight
        gpu_preflight(np, torch, nn, taverngym, device)
    if taverngym.OBS2_FLOATS != FEATURE_DIM or taverngym.OBS2_CARDS != CARD_DIM:
        raise RuntimeError(f"unexpected observe2 dims: {taverngym.OBS2_FLOATS}, {taverngym.OBS2_CARDS}")

    resume_payload = None
    if args.resume:
        from checkpoint_resume import load_resume
        resume_payload = load_resume(
            torch, args.resume, ruleset=ARENA_RULESET_ID,
            catalog=ARENA_CATALOG_SHA256, build=taverngym.build_info(),
            expected_sha256=args.resume_sha256)
    if args.rollout_data:
        x_feat, x_card, x_mask, y, game_ids = load_rollout_dataset(np, Path(args.rollout_data))
    else:
        x_feat, x_card, x_mask, y, game_ids = generate_bot_dataset(
            np, taverngym, samples=args.samples, seed=args.seed, max_games=args.max_games,
            teacher=args.teacher
        )
    print(f"dataset ready: samples={len(y)}", flush=True)
    unique_games = np.unique(game_ids)
    if len(unique_games) < 2:
        raise ValueError("need at least two games for independent validation")
    np.random.shuffle(unique_games)
    val_games = unique_games[:max(1, int(len(unique_games) * args.val_ratio))]
    validation = np.isin(game_ids, val_games)
    train_idx = np.flatnonzero(~validation)
    val_idx = np.flatnonzero(validation)
    print(f"split train={len(train_idx)} val={len(val_idx)} "
          f"games={len(unique_games)} val_games={val_games.tolist()}", flush=True)

    cfg = (ModelConfig(**resume_payload["model_config"]) if resume_payload else
           ModelConfig(card_vocab=max(int(x_card.max()) + 1, args.card_vocab)))
    if args.action_identity:
        cfg.action_identity = True
    if int(x_card.max()) >= cfg.card_vocab:
        raise ValueError("sample card vocabulary exceeds resumed model vocabulary")
    TavernBCPolicy = build_model_class(nn, torch)
    print(f"moving policy to {device}", flush=True)
    model = TavernBCPolicy(cfg)
    if resume_payload:
        from checkpoint_resume import load_policy_state
        load_policy_state(model, resume_payload)
    model = move_policy(torch, model, device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    best_val = float("inf")
    best_epoch = 0
    no_improve = 0
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    best_path = output_dir / "tavern_bc_policy.pt"
    if resume_payload:
        metrics = resume_payload["metrics"]
        save_checkpoint(torch, model, cfg, best_path, args,
                        metrics["val_loss"], metrics["val_acc"], taverngym)
        shutil.copy2(best_path, output_dir / "tavern_initial.pt")
        print("Warm start loaded; initial policy preserved before updates", flush=True)

    def batch_loss(indexes, train: bool):
        # Rollout npz 里是 float16/int16/uint8，统一在这里转成训练需要的 dtype。
        feat = move_tensor(torch, torch.from_numpy(x_feat[indexes]).float(), device)
        card = move_tensor(torch, torch.from_numpy(x_card[indexes]).long(), device)
        mask = move_tensor(torch, torch.from_numpy(x_mask[indexes]).bool(), device)
        target = move_tensor(torch, torch.from_numpy(y[indexes]).long(), device)
        logits = model(feat, card).masked_fill(~mask, -1e9)
        loss = F.cross_entropy(logits, target)
        pred = logits.argmax(dim=-1)
        acc = (pred == target).float().mean()
        if train:
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            opt.step()
        return float(loss.detach().cpu()), float(acc.detach().cpu())

    for epoch in range(1, args.epochs + 1):
        print(f"starting epoch={epoch}", flush=True)
        model.train()
        train_losses, train_accs = [], []
        for idx in iter_minibatches(np, len(train_idx), args.batch_size, shuffle=True):
            loss, acc = batch_loss(train_idx[idx], True)
            train_losses.append(loss)
            train_accs.append(acc)

        model.eval()
        val_losses, val_accs = [], []
        with torch.no_grad():
            for idx in iter_minibatches(np, len(val_idx), args.batch_size, shuffle=False):
                loss, acc = batch_loss(val_idx[idx], False)
                val_losses.append(loss)
                val_accs.append(acc)

        train_loss, train_acc = float(np.mean(train_losses)), float(np.mean(train_accs))
        val_loss, val_acc = float(np.mean(val_losses)), float(np.mean(val_accs))
        print(
            f"epoch={epoch} train_loss={train_loss:.4f} train_acc={train_acc:.4f} "
            f"val_loss={val_loss:.4f} val_acc={val_acc:.4f}",
            flush=True,
        )
        if val_loss < best_val:
            best_val = val_loss
            best_epoch = epoch
            no_improve = 0
            save_checkpoint(torch, model, cfg, best_path, args, val_loss, val_acc, taverngym)
            print(f"saved {best_path}", flush=True)
        else:
            no_improve += 1
            print(f"no val_loss improvement ({no_improve}/{args.patience})", flush=True)
            if args.patience > 0 and no_improve >= args.patience:
                print(f"early stopping at epoch={epoch}; best was epoch={best_epoch}",
                      flush=True)
                break

    model.load_state_dict(torch.load(best_path, map_location="cpu")["state_dict"])
    if args.rl_rounds:
        from tavern_ppo import train_ppo
        train_ppo(args, np, torch, nn, F, taverngym, model, cfg, device,
                  (x_feat, x_card, x_mask, y, train_idx))
    final_report = evaluate_policy(np, torch, taverngym, model, device,
                                   args.final_eval_games, args.final_eval_seed)
    reports = {"selected": final_report}
    if resume_payload:
        initial = TavernBCPolicy(ModelConfig(**resume_payload["model_config"]))
        initial.load_state_dict(resume_payload["state_dict"], strict=True)
        # CPU inference is allowed; all parameter updates above stay on GPU.
        reports["initial"] = evaluate_policy(
            np, torch, taverngym, initial, "cpu",
            args.final_eval_games, args.final_eval_seed)
    (output_dir / "independent_evaluation.json").write_text(
        json.dumps(reports, indent=2), encoding="utf-8")
    if args.league_pool:
        from league_rollout import evaluate, load_pool
        opponents, provenance = load_pool(np, torch, nn, taverngym, args.league_pool)
        league_reports = {"pool": provenance, "selected": {}, "initial": {}}
        for mode in ("bot", "mixed", "hard"):
            count = args.final_eval_games if mode == "bot" else args.league_final_games
            league_reports["selected"][mode] = evaluate(
                np, torch, taverngym, model, count, args.final_eval_seed,
                opponents=opponents, mode=mode)
            if resume_payload:
                league_reports["initial"][mode] = evaluate(
                    np, torch, taverngym, initial, count, args.final_eval_seed,
                    opponents=opponents, mode=mode)
        (output_dir / "league_evaluation.json").write_text(json.dumps(league_reports, indent=2))
    if args.capacity_ablation:
        from capacity_ablation import run
        run(args, np, torch, nn, F, taverngym, model,
            (x_feat, x_card, x_mask, y, train_idx, val_idx), device)
    print(f"final checkpoint: {best_path}", flush=True)


def save_checkpoint(torch, model, cfg: ModelConfig, path: Path, args, val_loss, val_acc, taverngym) -> None:
    payload = {
        "model_type": "TavernBCPolicy",
        "model_config": asdict(cfg),
        "state_dict": model.state_dict(),
        "ruleset_id": ARENA_RULESET_ID,
        "catalog_sha256": ARENA_CATALOG_SHA256,
        "taverngym_build_info": taverngym.build_info(),
        "train_args": vars(args),
        "metrics": {"val_loss": float(val_loss), "val_acc": float(val_acc)},
    }
    torch.save(payload, path)


def choose_model_action(np, torch, game, seat: int, model, device) -> int:
    f, c, m = decode_obs(np, game.observe2(seat), game.legal_mask(seat))
    with torch.no_grad():
        logits = model(
            move_tensor(torch, torch.from_numpy(f).unsqueeze(0), device),
            move_tensor(torch, torch.from_numpy(c.astype("int64")).unsqueeze(0), device),
        )[0].detach().cpu().numpy()
    logits = np.where(m, logits, -np.inf)
    action = int(np.argmax(logits))
    if not m[action]:
        raise RuntimeError("model selected illegal action after masking")
    return action


def evaluate_policy(np, torch, taverngym, model, device, games: int, seed: int):
    placements = []
    model.eval()
    for i in range(games):
        game = taverngym.Game(seed + i)
        learner = i % game.num_players
        guard = 0
        while not game.is_over():
            progressed = False
            for seat in range(game.num_players):
                if not game.needs_action(seat):
                    continue
                action = choose_model_action(np, torch, game, seat, model, device) if seat == learner else int(game.bot_action(seat))
                game.step(seat, action)
                progressed = True
            guard += 1
            if not progressed or guard > 50000:
                raise RuntimeError("evaluation game did not progress")
        placements.append(int(game.placements()[learner]))
        if (i + 1) % 32 == 0:
            print(f"independent eval progress={i+1}/{games}", flush=True)
    arr = np.asarray(placements)
    report = {"games": games, "seed": seed, "rotated_seats": True,
              "avg_place": float(arr.mean()), "top4": float((arr <= 4).mean()),
              "first": float((arr == 1).mean()), "placements": placements}
    print(
        "eval "
        f"games={games} avg_place={arr.mean():.3f} top4={(arr <= 4).mean():.3f} "
        f"first={(arr == 1).mean():.3f} placements={placements}",
        flush=True,
    )
    return report


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--install", action="store_true", help="apply observe2 patch if needed and pip install dependencies")
    parser.add_argument("--train", action="store_true", help="run behavior-cloning training")
    parser.add_argument("--cpu", action="store_true", help="force CPU even if CUDA is available")
    parser.add_argument("--samples", type=int, default=50000)
    parser.add_argument("--teacher", choices=("bot", "guide"), default="bot")
    parser.add_argument("--max-games", type=int, default=5000)
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--resume", help="checkpoint path, or auto for attached C2Net model")
    parser.add_argument("--rollout-data", default=None,
                        help="npz of self-play rollouts from tavern-arena/selfplay.py; "
                             "replaces bot/guide dataset generation")
    parser.add_argument("--resume-sha256", help="required starting artifact SHA256")
    parser.add_argument("--action-identity", action="store_true",
                        help="enable zero-initialized action-aligned card identity head")
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-3)
    parser.add_argument("--grad-clip", type=float, default=1.0)
    parser.add_argument("--patience", type=int, default=4,
                        help="early stopping patience; 0 disables")
    parser.add_argument("--val-ratio", type=float, default=0.1)
    parser.add_argument("--eval-games", type=int, default=16)
    parser.add_argument("--final-eval-games", type=int, default=256)
    parser.add_argument("--final-eval-seed", type=int, default=20401029)
    parser.add_argument("--seed", type=int, default=20261029)
    parser.add_argument("--card-vocab", type=int, default=4096)
    parser.add_argument("--rl-rounds", type=int, default=0)
    parser.add_argument("--rl-games", type=int, default=32)
    parser.add_argument("--ppo-epochs", type=int, default=4)
    parser.add_argument("--rl-lr", type=float, default=3e-5)
    parser.add_argument("--entropy-coef", type=float, default=0.01)
    parser.add_argument("--bc-anchor", type=float, default=0.1)
    parser.add_argument("--top4-bonus", type=float, default=0.0)
    parser.add_argument("--selection-interval", type=int, default=5)
    parser.add_argument("--target-top4", type=float, default=0.7)
    parser.add_argument("--target-avg-place", type=float, default=3.5)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--league-pool", help="frozen pool manifest path, or auto in C2Net")
    parser.add_argument("--league-mode", choices=("bot", "mixed", "hard", "curriculum"),
                        default="curriculum")
    parser.add_argument("--league-final-games", type=int, default=128)
    parser.add_argument("--stage-kl", type=float, default=0.1)
    parser.add_argument("--stage-kl-rounds", type=int, default=40)
    parser.add_argument("--gae-lambda", type=float, default=0.995)
    parser.add_argument("--recommendation-snapshot", help="optional public-guide reward snapshot")
    parser.add_argument("--composition-weight", type=float, default=0.1)
    parser.add_argument("--trinket-weight", type=float, default=0.05)
    parser.add_argument("--capacity-ablation", action="store_true")
    parser.add_argument("--capacity-epochs", type=int, default=8)
    parser.add_argument("--capacity-eval-games", type=int, default=64)
    args = parser.parse_args()
    if (args.samples < 1 or args.epochs < 0 or
            (args.epochs == 0 and not args.resume) or args.batch_size < 1 or
            args.eval_games < 1 or args.final_eval_games < 1 or
            args.rl_rounds < 0 or args.rl_games < 2 or
            args.ppo_epochs < 1 or args.selection_interval < 1 or
            args.top4_bonus < 0 or not 0 <= args.target_top4 <= 1 or
            not 1 <= args.target_avg_place <= 8 or not 0 < args.val_ratio < 1 or
            args.league_final_games < 1 or not 0 <= args.gae_lambda <= 1 or
            args.stage_kl < 0 or args.stage_kl_rounds < 0 or
            args.capacity_epochs < 1 or args.capacity_eval_games < 1 or
            (args.capacity_ablation and not args.league_pool) or
            (args.recommendation_snapshot and not args.league_pool) or
            not 0 <= args.composition_weight <= 0.1 or not 0 <= args.trinket_weight <= 0.05):
        parser.error("invalid sample, epoch, batch, evaluation, RL or validation limits")
    return args


def _resolve_rollout_data(ctx, value: str) -> str:
    """解析 --rollout-data。

    - `auto`：扫描 C2Net ctx 所有字符串属性 + 固定路径，rglob 唯一 rollouts_*.npz。
    - 硬编码路径：若路径存在直接用；若不存在**自动降级为 auto** 并警告。
    """
    if value != "auto":
        p = Path(value)
        if p.is_file():
            print(f"rollout data (explicit): {p}", flush=True)
            return str(p)
        print(f"WARNING: explicit rollout-data={value!r} not found, falling back to auto",
              flush=True)

    roots = []
    # C2Net 的挂载路径属性名随镜像版本变化，凡是指向已存在目录的字符串属性都试一遍。
    ctx_str_attrs = {}
    for attr in dir(ctx):
        if attr.startswith("_"):
            continue
        try:
            path = getattr(ctx, attr)
        except Exception:
            continue
        if isinstance(path, str):
            ctx_str_attrs[attr] = path
            if os.path.isdir(path):
                roots.append(Path(path))
    for fixed in ("/dataset", "/datasets", "/data", "/mnt/dataset", "/mnt", "/workspace", "/tmp"):
        if os.path.isdir(fixed):
            roots.append(Path(fixed))

    # DEBUG：把 ctx 的所有字符串属性和每个目录的一级内容打印出来
    print(f"[rollout-debug] ctx string attributes: {ctx_str_attrs}", flush=True)
    for root in dict.fromkeys(roots):
        try:
            entries = sorted(root.iterdir())[:20]
            print(f"[rollout-debug] scan root={root} entries={[e.name for e in entries]}",
                  flush=True)
        except Exception as e:
            print(f"[rollout-debug] scan root={root} error={e}", flush=True)

    seen = []
    for root in dict.fromkeys(roots):
        matches = sorted(root.rglob("rollouts_*.npz"))
        if len(matches) == 1:
            print(f"rollout data resolved: {matches[0]}", flush=True)
            return str(matches[0])
        if len(matches) > 1:
            raise ValueError(f"attached dataset has multiple rollouts_*.npz: {matches}")
        seen.append(str(root))
    raise ValueError(
        f"rollout-data=auto found no rollouts_*.npz under: {seen}\n"
        f"ctx string attrs: {ctx_str_attrs}"
    )


def main() -> None:
    # #region debug-point H1:H2-stack
    faulthandler.enable()
    faulthandler.dump_traceback_later(60, repeat=True)
    # #endregion
    args = parse_args()
    upload = None
    if find_spec("c2net") is not None:
        from c2net.context import prepare, upload_output

        ctx = prepare()
        if getattr(ctx, "pretrain_model_path", None):
            os.environ["TAVERN_PRETRAIN_MODEL_DIR"] = str(ctx.pretrain_model_path)
        if args.resume == "auto":
            model_root = getattr(ctx, "pretrain_model_path", None)
            if not model_root:
                raise ValueError("resume=auto requires an attached C2Net pretrained model")
            matches = list(Path(model_root).rglob("tavern_bc_policy.pt"))
            if len(matches) != 1:
                raise ValueError("attached model must contain exactly one tavern_bc_policy.pt")
            args.resume = str(matches[0])
        if args.league_pool == "auto":
            model_root = getattr(ctx, "pretrain_model_path", None)
            matches = list(Path(model_root).rglob("opponent_pool.json")) if model_root else []
            if len(matches) != 1:
                raise ValueError("league-pool=auto requires exactly one attached opponent_pool.json")
            args.league_pool = str(matches[0])
        output_root = Path(ctx.output_path).resolve()
        destination = Path(args.output_dir).resolve() if args.output_dir else output_root
        if not destination.is_relative_to(output_root):
            raise ValueError("--output-dir must be within c2net output_path")
        args.output_dir = str(destination)
        if args.rollout_data and args.train:
            args.rollout_data = _resolve_rollout_data(ctx, args.rollout_data)
        upload = upload_output
        print(f"C2Net output directory: {args.output_dir}", flush=True)
    else:
        args.output_dir = args.output_dir or os.getenv("OUTPUT_PATH", "outputs")
    if not args.install and not args.train:
        args.install = True
        args.train = True
    if args.install:
        install_environment()
    if args.train:
        train_bc(args)
        if upload is not None:
            upload()
            print("C2Net output upload returned", flush=True)


if __name__ == "__main__":
    main()
