AutoTavern Desktop V2 (windows)
Run desktop_tavern/setup-windows.cmd first.
Read docs/DESKTOP_V2.md. Default mode is recommendations.
The bundled geometry/log are synthetic offline samples only.
No real game-client acceptance has been completed.
